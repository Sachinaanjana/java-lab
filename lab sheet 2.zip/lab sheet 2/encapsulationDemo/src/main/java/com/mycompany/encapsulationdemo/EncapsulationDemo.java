package com.mycompany.encapsulationdemo;
public class EncapsulationDemo{
    private String empName;
    public String getEmpName(){
        return empName;
    }

    public void setEmpName(String newValue){
        empName = newValue;
    }

}

