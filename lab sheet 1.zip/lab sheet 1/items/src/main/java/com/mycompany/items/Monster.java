package com.mycompany.items;
public class Monster extends Item {
    
    public Monster(int location, String description) {
        
        super(location, description);
    }
}

